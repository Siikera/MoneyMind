import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



// Removed duplicate imports

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class BancosModule { }
