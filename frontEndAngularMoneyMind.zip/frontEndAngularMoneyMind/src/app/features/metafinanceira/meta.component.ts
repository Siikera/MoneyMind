import { Component, ChangeDetectorRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MetaFinanceiraService, MetaFinanceiraDTO } from './meta.service';
import { NgIf, CommonModule } from '@angular/common';

@Component({
 selector: 'app-meta',
 standalone: true,
 imports: [FormsModule, NgIf, CommonModule],
 templateUrl: './meta.html',
 styleUrls: ['./meta.css']
})
export class MetaFinanceiraCadastroComponent {
 metaEditando: MetaFinanceiraDTO | null = null;
    
    // PROPRIEDADES DE ESTADO DA EDIÇÃO
    // Adicionado na correção anterior
    statusMeta: number | undefined; 
    // NOVO: Propriedade para armazenar o ID da Conta sendo editada
    idConta: number | undefined; 
    
 editarMetaFinanceira(meta: MetaFinanceiraDTO) {
  this.metaEditando = { ...meta };
  this.descricaoMeta = meta.descricaoMeta;
  this.prazo = meta.prazo;
  this.valor = meta.valor;
    
    // ATUALIZADO: Copia o statusMeta e idConta
    this.statusMeta = meta.statusMeta; 
    this.idConta = meta.idconta; // NOVO: Copia o idConta
 }

  salvarAlteracao(meta: MetaFinanceiraDTO) {
   if (!this.descricaoMeta.trim()) {
    this.error = 'Descrição da Meta é obrigatória.';
    return;
   }
   this.loading = true;
        
      // ATUALIZADO: Inclui statusMeta e idConta no DTO de atualização
   this.metaService.updateMetaFinanceira(meta.idMeta!, { 
            descricaoMeta: this.descricaoMeta, 
            prazo: this.prazo, 
            valor: this.valor, 
            statusMeta: this.statusMeta, // Manutenção do status
            idconta: this.idConta         // NOVO: Envia o idConta
        }).subscribe({
    next: () => {
     this.loading = false;
     this.success = true;
     this.metaEditando = null;
     this.descricaoMeta = '';
          this.prazo = ''; // Limpando campos após sucesso
          this.valor = 0;
          this.statusMeta = undefined; // Limpa o status
          this.idConta = undefined;    // NOVO: Limpa o idConta
     this.listarMetaFinanceiras();
     this.cdr.detectChanges();
     setTimeout(() => {
      this.success = false;
      this.cdr.detectChanges();
     }, 2000);
    },
    error: (err: any) => {
     this.error = err?.error?.message || err?.error || 'Erro ao alterar meta.';
     this.loading = false;
    }
   });
  }

  cancelarEdicao() {
   this.metaEditando = null;
   this.descricaoMeta = '';
   this.prazo = '';
   this.valor = 0;
      this.statusMeta = undefined; // Limpa o status
      this.idConta = undefined;    // NOVO: Limpa o idConta
   this.error = '';
  }

 excluirMetaFinanceira(id: number) {
  if (confirm('Tem certeza que deseja excluir esta meta finaceira?')) {
   this.metaService.excluirMetaFinanceira(id).subscribe({
    next: () => {
     this.listarMetaFinanceiras();
    },
    error: () => {
     alert('Erro ao excluir meta finaceira.');
    }
   });
  }
 }

 cadastrarMetaFinanceira(meta: MetaFinanceiraDTO) {
  // Aqui você pode redirecionar para uma tela de cadastro de meta ou abrir um modal
  alert('Funcionalidade de cadastro de meta para: ' + meta.descricaoMeta);
 }
 descricaoMeta = '';
 prazo = '';
 valor = 0;
 error = '';
 success = false;
 loading = false;
 metas: MetaFinanceiraDTO[] = [];
 mostrarLista = false;

 constructor(private metaService: MetaFinanceiraService, private cdr: ChangeDetectorRef) {
  this.listarMetaFinanceiras();
 }

 toggleLista() {
  this.mostrarLista = !this.mostrarLista;
 }

 listarMetaFinanceiras() {
  this.metaService.getMetaFinanceiras().subscribe({
   next: (data) => {
    console.log('Dados recebidos do backend:', data);
    this.metas = [...data];
    this.cdr.detectChanges();
   },
   error: (err) => {
    console.error('Erro ao buscar metas:', err);
    this.metas = [];
    this.cdr.detectChanges();
   }
  });
 }

 onSubmit() {
  this.error = '';
  this.success = false;
  if (!this.descricaoMeta.trim()) {
   this.error = 'Descrição da Meta é obrigatória.';
   return;
  }
  this.loading = true;
  if (this.metaEditando && this.metaEditando.idMeta) {
   this.metaService.updateMetaFinanceira(this.metaEditando.idMeta, { 
            descricaoMeta: this.descricaoMeta, 
            prazo: this.prazo, 
            valor: this.valor, 
            statusMeta: this.statusMeta, // Manutenção do status
            idconta: this.idConta         // NOVO: Envia o idConta
        }).subscribe({
    next: () => {
     this.loading = false;
     this.success = true;
     this.descricaoMeta = '';
     this.metaEditando = null;
     this.listarMetaFinanceiras();
          this.statusMeta = undefined; // Limpa o status
          this.idConta = undefined;    // NOVO: Limpa o idConta
     this.cdr.detectChanges();
     setTimeout(() => {
      const input = document.getElementById('descricaoMeta') as HTMLInputElement;
      if (input) {
       input.value = '';
       input.focus();
      }
     }, 0);
     setTimeout(() => {
      this.success = false;
      this.cdr.detectChanges();
     }, 2500);
    },
 error: (err: any) => {
     this.error = err?.error?.message || err?.error || 'Erro ao alterar meta.';
     this.loading = false;
    }
   });
  } else {
   // Cadastro
      // ATUALIZADO: Inclui idConta no objeto de cadastro (se tiver um valor)
   this.metaService.createMetaFinanceira({ 
            descricaoMeta: this.descricaoMeta, 
            prazo: this.prazo, 
            valor: this.valor,
            idconta: this.idConta // NOVO: Envia o idConta no cadastro (se o formulário tiver um campo para ele)
        }).subscribe({
    next: () => {
     this.loading = false;
     this.success = true;
     this.descricaoMeta = '';
     this.listarMetaFinanceiras();
     this.cdr.detectChanges();
     setTimeout(() => {
      const input = document.getElementById('descricaoMeta') as HTMLInputElement;
      if (input) {
       input.value = '';
       input.focus();
      }
     }, 0);
     setTimeout(() => {
      this.success = false;
      this.cdr.detectChanges();
     }, 2500); // mensagem some após 2,5 segundos
    },
    error: (err) => {
     // Trata diferentes formatos de erro do backend
     if (typeof err?.error === 'string' && err.error.includes('Descrição da Meta já cadastrado')) {
      this.error = err.error;
     } else if (err?.error?.message && err.error.message.includes('Descrição da Meta já cadastrado')) {
      this.error = err.error.message;
     } else if (err?.status === 409) {
      this.error = 'Descrição da Meta já cadastrada.';
     } else {
      this.error = err?.error?.message || err?.error || 'Erro ao cadastrar meta.';
     }
     this.loading = false;
    }
   });
  }
 }
}